# Vliegbasis71 SID Studio 64 v0.3.3 — Ronde 3C.1
ChatID 8F2C7A41. Patch op basis van werkende v0.3.2.

## Nieuw
- Speelwyse: Regstreeks / Stappe / Arpeggio.
- Arpeggio: op, af, op-en-af, willekeurig, speelvolgorde.
- Hou vas standaard UIT; AAN houdt tonen vast na Note Off.
- Host MIDI wordt vóór sequencer-events op dezelfde sample verwerkt.
- De bestaande 16/32-stappensequencer blijft beschikbaar.
- Nieuw: test_arpeggiator; agile backlog in AGILE_BACKLOG.md.

## Build (macOS)
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 4
ctest --test-dir build --output-on-failure
auval -v aumu Si64 Vl71
```

## Logic-test
Kies Reekse > Speelwyse = Arpeggio, Hou vas UIT, 1/16. Zet Logic op 88 BPM, start transport, houd C-E-G ingedrukt. Test daarna Hou vas AAN, stop, en wissel 120 BPM.
Voor zelfstandige stappen kies Speelwyse = Stappe, zet stappen 1/5/9/13 aan en start Logic. Bestaande 'Reeks aan' is nog als legacy-schakelaar beschikbaar.

## Grenzen
Dit pakket is niet op macOS met JUCE/Logic gecompileerd. Een geslaagde ctest bewijst niet dat audio in Logic hoorbaar is. MIDI-transport en sample-grensgevallen vragen verdere integratietests. De UI is een eerste uitbreiding.
