// Vliegbasis71 | v0.3.3 | ChatID 8F2C7A41
#pragma once
#include <array>
#include <cstdint>
namespace sid64 {
class Arpeggiator {
public:
 void noteOn(int note) noexcept;
 void noteOff(int note, bool hold) noexcept;
 void clear() noexcept;
 int next(int direction) noexcept; // 0 up, 1 down, 2 up-down, 3 random, 4 played order
 int count() const noexcept { return size_; }
private:
 std::array<int,128> held_{};
 std::array<int,128> order_{};
 int size_=0, position_=0, travel_=1;
 uint32_t seed_=0x12345678u;
};
}
