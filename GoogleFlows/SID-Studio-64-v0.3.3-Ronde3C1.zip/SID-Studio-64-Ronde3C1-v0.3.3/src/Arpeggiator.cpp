// Vliegbasis71 | v0.3.3 | ChatID 8F2C7A41
#include "Arpeggiator.hpp"
#include <algorithm>
namespace sid64 {
void Arpeggiator::noteOn(int n) noexcept {
 if(n<0||n>127||held_[n]) return;
 held_[n]=1;order_[size_++]=n;position_=0;travel_=1;
}
void Arpeggiator::noteOff(int n,bool hold) noexcept {
 if(n<0||n>127||hold||!held_[n]) return;
 held_[n]=0;for(int i=0;i<size_;++i)if(order_[i]==n){for(int j=i;j<size_-1;++j)order_[j]=order_[j+1];--size_;break;}
 position_=0;travel_=1;
}
void Arpeggiator::clear() noexcept {held_.fill(0);size_=0;position_=0;travel_=1;}
int Arpeggiator::next(int direction) noexcept {
 if(size_==0)return -1;
 std::array<int,128> notes=order_;
 if(direction!=4)std::sort(notes.begin(),notes.begin()+size_);
 int index=0;
 if(direction==3){seed_^=seed_<<13;seed_^=seed_>>17;seed_^=seed_<<5;index=static_cast<int>(seed_%static_cast<uint32_t>(size_));}
 else if(direction==1){index=size_-1-position_;position_=(position_+1)%size_;}
 else if(direction==2){index=position_;if(size_>1){position_+=travel_;if(position_>=size_-1){position_=size_-1;travel_=-1;}else if(position_<=0){position_=0;travel_=1;}}}
 else {index=position_;position_=(position_+1)%size_;}
 return notes[index];
}
}
