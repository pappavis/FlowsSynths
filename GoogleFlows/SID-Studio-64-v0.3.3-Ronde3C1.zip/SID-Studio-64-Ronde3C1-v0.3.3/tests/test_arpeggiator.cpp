// Vliegbasis71 | v0.3.3 | ChatID 8F2C7A41
#include "Arpeggiator.hpp"
#include <cassert>
int main(){
 sid64::Arpeggiator a;
 a.noteOn(67);a.noteOn(60);a.noteOn(64);
 assert(a.count()==3);
 assert(a.next(0)==60);assert(a.next(0)==64);assert(a.next(0)==67);assert(a.next(0)==60);
 a.clear();a.noteOn(67);a.noteOn(60);a.noteOn(64);
 assert(a.next(1)==67);assert(a.next(1)==64);assert(a.next(1)==60);
 a.clear();a.noteOn(60);a.noteOn(64);a.noteOn(67);
 assert(a.next(2)==60);assert(a.next(2)==64);assert(a.next(2)==67);assert(a.next(2)==64);assert(a.next(2)==60);
 a.clear();a.noteOn(67);a.noteOn(60);a.noteOn(64);
 assert(a.next(4)==67);assert(a.next(4)==60);assert(a.next(4)==64);
 a.noteOff(60,false);assert(a.count()==2);
 a.noteOff(64,true);assert(a.count()==2);
 a.clear();assert(a.next(0)==-1);
}
