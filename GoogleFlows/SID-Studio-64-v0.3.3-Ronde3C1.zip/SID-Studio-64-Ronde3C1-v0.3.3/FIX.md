# Wijzigingen v0.3.2 — E2C7A94F
- JUCE host playhead uitlezen; BPM en PPQ als muzikale tijdbron.
- Nieuwe 16/32 stappenreeks met samplepositie-events.
- 32 opgeslagen stapparameters en MIDI noot/verdeler/aan-uit.
- Pagina Reekse krijgt eigen layout; verborgen Klank-knoppen bij pagina wissel.
- Bestaande SID engine en 3B klankparameters blijven ongewijzigd.
- Audio Unit-versie volgt CMake project 0.3.2.
